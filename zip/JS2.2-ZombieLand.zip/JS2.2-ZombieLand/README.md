# ZombieLand : Un zombie sort de terre

## Enoncé
Nous allons utiliser requestAnimationFrame pour animer un Zombie qui se réveil.
Pour cela vous avez à votre disposition une planche de sprites comportant toutes les étapges de l'animation du zombie (11 exactement).

### Fonctionnement attendu
Au chargement de la page le Zombie sort de terre puis disparait et l'aniomation tourne en boucle.

### Remarques

 - Pour réussir cet exercice nous allons devoir calculer le taux de rafraichissement. A quelle vitesse allons nous rafraichir notre Zombie pour avoir une animation fluide et pas trop rapide ?
 - Comment allons nous faire pour afficher la bonne image du Zombie à chaque animation (image sélectionnée dans la planche de sprite)

### Bonus (à faire)

- une fois le zombie sorti de terre l'animation s'arrête et le Zombie reste visible
- après cette première étape, il est alors possible de déplacer de la Zombie à droite et à gauche avec les flèches du clavier